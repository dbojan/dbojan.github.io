//convert sub format to srt
//enable c++11 by adding CONFIG += c++11 to pro file (in Qt)

#include <iostream>
#include <fstream> //open read file
#include <sstream>
#include <iomanip> //setw
#include <string> //to string? or sstream

using namespace std;


double frames=0;

string timeConvert(int framePosition){




    int time = framePosition/::frames;
    //146862 / 25
    // 5874.48
    // 01:37:54,480


    string c = to_string(framePosition/::frames);


    //3 digits after .
    c = c.substr( c.find(".")+1,3 );


    string hour,min,sec;

    hour=to_string(time/3600);
    time=time%3600;
    min=to_string(time/60);
    time=time%60;
    sec=to_string(time);


    stringstream ss;
    ss << setw(2) <<setfill('0') << hour<< ":" << setw(2) <<setfill('0') << min<< ":" << setw(2) <<setfill('0') <<sec<< ","<<c  ;
    return  ss.str();



}



int main(int argc, char* argv[])
{


    //we need at least 4 args
    if (argc<4) {
        cout << "How to use: \nsub2srt input.sub output.srt fps" << endl;
        exit(1);
    }

    //0 is exe name, 1 is first arg...
    ifstream infile(argv[1]);


    //delete output if exists
   if (argv[2]) {
          remove( argv[2] );
       }

   ofstream outfile(argv[2]);

    //global variable
    ::frames = stod(argv[3]);




    string line;
    int counter =1 ;
    if (infile.is_open())
    {
        while ( getline (infile,line) )
        {


            size_t found = line.find("|");
            if (found!=std::string::npos)
            {
                line.replace(line.find("|"), 1, "\n");
            }

            //string line= "{234}{2001}{y:i}prevod sa engelskog i obrada|Gaca62";

            //search from position 2 (first is 0, second is 1, ...)
            //for {}
            int positionOfBrackets = line.find("}{",1);

            //start time
            //after {, till before }{
            //substr (starting position which starts with 0, length)
            string tstart = line.substr (1,positionOfBrackets-1);

            //end time, from }{, till before the second }
            int positionOfRightBracket = line.find("}",positionOfBrackets+2);

            //substr (starting position which starts with 0, length)
            // - already used part
            string tend =line.substr (positionOfBrackets+2, positionOfRightBracket-(positionOfBrackets+2));

            string text =line.substr (positionOfRightBracket+1);


            outfile <<  counter << "\n" << timeConvert( stoi(tstart) ) << " --> " <<  timeConvert(  stoi(tend) ) << "\n" << text << endl<< endl;
            ++counter;





        }
        infile.close();
    }

    else cout << "Unable to open file " << infile << endl;




}

