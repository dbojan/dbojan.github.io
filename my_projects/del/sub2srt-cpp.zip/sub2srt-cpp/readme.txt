Info: 
v1.0
Convert MicroDVD (sub) format to Subrip (srt).


How to use:
sub2srt.exe in.sub out.srt fps

Example:
sub2srt.exe "d:\movie.sub" "d:\movie.srt" 23.976

Compile.bat is if you want to compile yourself.
Compiled using qt 5.2 +  minigw, with switch for c++11
Licence: BSD


This info is from python version:
--
todo: unicode output.
use iconv for now:
iconv.exe" -f ms-ee -t utf-8 file.srt >file-u.srt

use Subtitle workshop if you need gui.
--


--
https://sourceforge.net/projects/sub2srt-cpp/
dbojan.tk
