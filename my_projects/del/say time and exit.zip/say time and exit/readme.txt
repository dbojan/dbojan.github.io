say time and exit, for android

v0.99


bsd licence


--
http://dbojan.tk


