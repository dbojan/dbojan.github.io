You can open .odt with openoffice.org
You can print 2x (single a3 page ) on a4 page using cuteprint (preferences/layout/pages per sheet=2).
Cuteprint will create .pdf file, which you can later print on a4 paper.